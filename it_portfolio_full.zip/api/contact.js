export default function handler(req, res) {
  if (req.method === "POST") {
    const { name, email, message } = req.body;
    if (!name || !email || !message) {
      return res.status(400).json({ message: "Missing fields" });
    }
    return res.status(200).json({ message: "Message sent!" });
  }
  res.status(405).json({ message: "Method not allowed" });
}
