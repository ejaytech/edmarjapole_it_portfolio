import React, { useState } from "react";

export default function App() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await fetch("/api/contact", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(form),
    });
    const data = await res.json();
    alert(data.message);
  };

  return (
    <div style={{padding: "40px", fontFamily: "Arial"}}>
      <h1>Edmar Japole - IT Support Specialist</h1>
      <p>Remote IT Support | System Maintenance | Network Troubleshooting</p>

      <h2>Contact Me</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Name" onChange={(e)=>setForm({...form,name:e.target.value})}/><br/><br/>
        <input placeholder="Email" onChange={(e)=>setForm({...form,email:e.target.value})}/><br/><br/>
        <textarea placeholder="Message" onChange={(e)=>setForm({...form,message:e.target.value})}></textarea><br/><br/>
        <button type="submit">Send Message</button>
      </form>
    </div>
  );
}
